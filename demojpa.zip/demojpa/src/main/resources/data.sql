
insert into course(id,name)values(100,'Gaurav');