package com.in28minutes.jpa.hibernate.demojpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemojpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
